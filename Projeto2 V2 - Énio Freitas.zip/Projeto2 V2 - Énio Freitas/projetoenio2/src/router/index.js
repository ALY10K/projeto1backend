import { createRouter, createWebHistory } from 'vue-router'
import { getAuth, onAuthStateChanged } from 'firebase/auth'
import HomeView from '../views/HomeView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/jogos',
      name: 'jogos',
      component: () => import('../views/Games.vue')
    },
    {
      path: '/registar',
      name: 'registar',
      component: () => import('../views/Register.vue')
    },
    {
      path: '/entrar',
      name: 'entrar',
      component: () => import('../views/Login.vue')
    },
    {
      path: '/favoritos',
      name: 'favoritos',
      component: () => import('../views/Favorites.vue'),
      meta: {
        requiresAuth: true,
      }
    },
  ]
})

const getCurrentUser = () => {
  return new Promise((resolve, reject) => {
    const removeListener = onAuthStateChanged(
      getAuth(),
      (user) => {
        removeListener();
        resolve(user);
      },
      reject
    )
  })
}

router.beforeEach(async (to, from, next) => {
  if (to.matched.some((record) => record.meta.requiresAuth)) {
    if (await getCurrentUser()) {
      next();
    } else {
      alert("Acesso Recusado | Necessitas fazer Login !");
      next('/');
    }  
  } else {
    next();
  }
});

export default router
