<script setup>

</script>

<template>

    <video id="main-video" preload="auto" class="fullscreen" autoplay="autoplay" loop="loop" muted="muted">
        <source type="video/mp4" src="@/assets/video.mp4" >
    </video>
  <div class="container6">
    <p>
    © Projeto Elaborado por <strong>Énio Freitas</strong> | <strong>UMA</strong> - Universidade da Madeira 2024
    </p>
  </div>
</template>

<style>
  @import 'bulma/css/bulma.min.css';
  .container6{
    padding-top: 1.1%;
    padding-bottom: 1.2%;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    text-align: center;
  }
</style>
