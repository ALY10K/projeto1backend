<template>
    <nav class="navbar" role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
          <a class="navbar-item" href="#">
            <img src="https://creativetoys.pt/wp-content/uploads/CreativeToysID-Positivo-escalacinzas@4x.png" alt="" width="200px">
          </a>
      
          <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
          </a>
        </div> 
        <div id="navbarBasicExample" class="navbar-menu">
          <div class="navbar-end">
            <div class="navbar-item">
              <div class="buttons">
                <RouterLink class="navbar-item" to="/">Inicio</RouterLink>
                <RouterLink class="navbar-item" to="/jogos">Biclioteca de Jogos</RouterLink>
                <RouterLink class="navbar-item" to="/favoritos">Carrinho</RouterLink>
                <div class="navbar-item" >|</div>
                <RouterLink class="button is-info" v-if="!isLoggedIn" to="/registar">Registar</RouterLink>
                <RouterLink class="button is-success" v-if="!isLoggedIn" to="/entrar">Entrar</RouterLink>
                <button class="button is-danger" @click="handleSignOut" v-if="isLoggedIn">Sair [<div v-if="userEmail"> {{ userEmail }}</div>]</button>
              </div>
            </div>
          </div>
        </div>
      </nav>

</template>

<script setup>
  import { onMounted, ref } from 'vue';
  import { getAuth, onAuthStateChanged, signOut } from 'firebase/auth';

  const isLoggedIn = ref(false);
  const userEmail = ref(null);

  let auth;
  onMounted (() => {
    auth = getAuth();
    onAuthStateChanged(auth, (user) => {
      if (user) {
        isLoggedIn.value = true;
        userEmail.value = user.email;
      } else {
        isLoggedIn.value = false;
        userEmail.value = null;
      }
    });
  });

  const handleSignOut = () => {
    signOut(auth).then(() => {
      router.push("/");
    })
  }
</script>

<style scoped>
@import 'bulma/css/bulma.min.css';

.navbar{
  background-color: rgb(34, 41, 48);
}

.navbar-item{
  color: white;
}
</style>
