import { defineStore } from 'pinia'
import { doc, setDoc } from 'firebase/firestore'


export const useJogoStore = defineStore('carrinho', {
    actions:{
        async addJogo(newJogo){
            let id = new Date().getTime().toString()

            await setDoc(doc(useJogoStore, id), {
                content: newJogo
            })
        }
    }
})