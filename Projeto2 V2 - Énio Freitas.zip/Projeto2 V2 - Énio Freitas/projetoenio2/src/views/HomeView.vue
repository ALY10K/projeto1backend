<script setup>
import Inicio from '../components/Inicio.vue'
</script>

<template>
  <main>
    <Inicio />
  </main>
</template>
