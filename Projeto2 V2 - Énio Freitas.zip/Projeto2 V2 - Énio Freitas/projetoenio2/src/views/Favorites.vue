<template>
<br>
    <div class="geraltitulo">
        <div class="titulofavoritos">
          <p class="title is-8">Os Meus Jogos Favoritos</p>
        </div>
    </div>
<br>
{{ store.carrinhoCompras }} 
<br>

<button class="button is-link has-background-sucess" @click="store2.addJogo(store.carrinhoCompras)">
    Adicionar
</button>
</template>

<script setup>
    import { ref } from 'vue';
    import { RouterLink } from 'vue-router';
    import { useCounterStore } from '@/stores/counter'
    import { useJogoStore } from '@/stores/jogos'
    import { getDatabase, ref as dbRef, set } from "firebase/database";
    import { getAuth } from "firebase/auth";

    let addJogos = (name) => {
    const db = getDatabase();
    const auth = getAuth();
    if (auth.currentUser) {
        const uid = auth.currentUser.uid;
        const carrinhoRef = dbRef(db, `/carrinho/${uid}/${store.carrinhoCompras}`);
        set(carrinhoRef, store.carrinhoCompras)
        .then(() => {
            console.log('Favorite saved!', store2.carrinhoCompras);
        });
    } else {
        console.log('Cannot save favorite. User is not authenticated.');
        alert('Cannot save favorite. User is not authenticated.');
    }
};

    const store = useCounterStore()
    const store2 = useJogoStore()
    const newJogo = ref('')
</script>

<style>
  @import 'bulma/css/bulma.min.css';
  .geraltitulo{
    width: 100%;
  }
  .titulofavoritos{
    display: flex;
    justify-content: center;
    text-align: center;
  }
</style>