<template>
    <div class="container">
        <div class="card" id="card3">
        <div class="card-image">
            <div class="media-content">
            <p class="title is-8" id="titulo2">Criar Conta</p>
        </div>
        <br>
            <p>Introduza um E-Mail</p>
            <p><input class="input is-rounded" type="text" placeholder="Email" v-model="email"></p>
            <br>
            <p>Introduza uma Palavra-Passe</p>
            <p><input class="input is-rounded" type="password" placeholder="Password" v-model="password"></p>
            <br>
            <p><button class="button is-rounded is-info" @click="register">Criar Conta</button></p>
        </div>
        </div>
    </div>
    <div class="container2"></div>
</template>

<script setup>
    import { ref } from 'vue';
    import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
    import { useRouter } from 'vue-router';

    const email = ref("");
    const password = ref("");
    const router = useRouter()

    const register = () => {
        const auth = getAuth()
        createUserWithEmailAndPassword(auth, email.value, password.value)
        .then((data) => {
            console.log("Registado Com Sucesso !");
            console.log(auth.currentUser)
            router.push('/jogos')
        })
        .catch((error) => {
            console.log(error.code);
            alert(error.message);
        })
    }
</script>

<style>
    @import 'bulma/css/bulma.min.css';
    #card3{
        width: 30%;
        text-align: center;
        padding-top: 50px;
        padding-bottom: 50px;
        padding-left: 50px;
        padding-right: 50px;
        background-color: rgb(34, 41, 48);
        color: white;
    }
    .container{
        width: 100%;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        margin-top: 25vh;
    }
    .container2{
        width: 100%;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        margin-top: 28vh;
    }
    #titulo2{
        color: white;
    }
</style>