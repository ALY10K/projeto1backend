<template>
    <div class="container">
        <div class="card" id="card2">
        <div class="card-image">
            <div class="media-content">
            <p class="title is-8" id="titulo">Iniciar Sessao</p>
        </div>
        <br>
            <p>Introduza o seu E-Mail</p>
            <p><input class="input is-rounded" type="text" placeholder="Email" v-model="email"></p>
            <br>
            <p>Introduza a sua Palavra-Passe</p>
            <p><input class="input is-rounded" type="password" placeholder="Password" v-model="password"></p>
            <p v-if="errMsg">{{ errMsg }}</p>
            <br>
            <p><button class="button is-success is-rounded" @click="register">Iniciar Sessao</button></p>
        </div>
        </div>
    </div>
    <div class="container2"></div>
</template>

<script setup>
    import { ref } from 'vue';
    import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
    import { useRouter } from 'vue-router';

    const email = ref("");
    const password = ref("");
    const errMsg = ref()
    const router = useRouter()

    const register = () => {
        const auth = getAuth()
        signInWithEmailAndPassword(auth, email.value, password.value)
        .then((data) => {
            console.log("Entrou Com Sucesso !");
            console.log(auth.currentUser)
            router.push('/jogos')
        })
        .catch((error) => {
            console.log(error.code);
            switch (error.code) {
                case "auth/invalid-email":
                    errMsg.value = "E-Mail Inválido";
                    break;
                case "auth/user-not-found":
                    errMsg.value = "Nao existe nenhuma conta com este Utilizador";
                    break;
                case "auth/wrong-password":
                    errMsg.value = "Palavra-Passe Errada";
                    break;
                default:
                    errMsg.value = "E-Mail ou Palavra-Passe Errada"
                    break;
            }    
        })
    }
</script>

<style>
    @import 'bulma/css/bulma.min.css';
    #card2{
        width: 30%;
        text-align: center;
        padding-top: 50px;
        padding-bottom: 50px;
        padding-left: 50px;
        padding-right: 50px;
        background-color: rgb(34, 41, 48);
        color: white;
    }
    .container{
        width: 100%;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        margin-top: 25vh;
    }
    .container2{
        width: 100%;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        margin-top: 28vh;
    }
    #titulo{
        color: white;
    }
</style>