<template>
<br>
    <div class="geraltitulo2">
        <div class="titulofavoritos2">
          <p class="title is-8">Encontre os seus Jogos Desejados</p>
        </div>
    </div>
<br>
    <div class="geral">
        <div class="pesquisabarra">
          <input class="input is-rounded" type="text" v-model="pesquisa" placeholder="Encontre o Jogo que deseja...">
        </div>

      <div class="botaopesquisar">
        <button @click="getGame(pesquisa)" class="button is-rounded" >Pesquisar</button>
      </div>
    </div>
<br>
<div class="container">
  <div v-for="item in game" class="card">
    <div class="card-image">
    <figure class="image is-4by3">
    <img :src="item.thumbnail" alt="" width="75">
    </figure>
      </div>
      <div class="card-content">
        <div class="media">
          <div class="media-content">
          <p class="title is-4" id="titulogames">{{ item.title }}</p>
          <p class="subtitle is-6" id="plataforma">Plataforma: {{ item.platform }}</p>
          </div>
        </div>
        <div class="content">
        <button class="button is-rounded is-warning" @click="addJogos(item)">Adicionar ao Carrinho</button>
        </div>
    </div>
  </div>
</div>
</template>

<script setup>  
import { ref } from 'vue'
import { useCounterStore } from '@/stores/counter'
import { getDatabase, ref as dbRef, set } from "firebase/database";
import { getAuth } from "firebase/auth";
const store = useCounterStore()

const game = ref('')
const pesquisa = ref('')
const carrinho = ref([])

let addJogos = (item) => {
    const db = getDatabase();
    const auth = getAuth();
    if (auth.currentUser) {
        const uid = auth.currentUser.uid;
        const carrinhoRef = dbRef(db, `/carrinho/${uid}/`);
        set(carrinhoRef, item)
        .then(() => {
            console.log('Jogo adicionado ao carrinho!', item);
        });
    } else {
        console.log('Erro ao adicionar o Jogo ao carrinho. Precisa Iniciar Sessão.');
        alert('Erro ao adicionar o Jogo ao carrinho. Precisa Iniciar Sessão.');
    }
  }

const getGame = (escolher) => fetch("https://www.freetogame.com/api/games?platform=" + escolher)
.then(dados => dados.json())
.then(resultado  => game.value = resultado)
</script>

<style scoped>
  @import 'bulma/css/bulma.min.css';
  .card{
      width: 20%;
      background-color: #585627;
  }
  .container{
    width: 100%;
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    text-align: center;
    gap: 15px;
  }
  .geral{
    width: 100%;
    display: flex;
    flex-wrap: wrap;
  }
  .botaopesquisar{
    width: 50%;
  }
  #titulogames{
    color: white;
  }
  #plataforma{
    color: white;
  }
  .titulofavoritos2{
    display: flex;
    justify-content: center;
    text-align: center;
  }
  .geraltitulo2{
    width: 100%;
  }
</style>
