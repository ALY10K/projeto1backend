import './assets/main.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import router from './router'

import { getDatabase } from "firebase/database";
import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyALd7e2BDj8oA-I4UXPHQzV6B3AZtSfVWc",
  authDomain: "projetoenio2.firebaseapp.com",
  projectId: "projetoenio2",
  storageBucket: "projetoenio2.appspot.com",
  messagingSenderId: "947410015325",
  appId: "1:947410015325:web:b29c90da8ba2bc8ddaa9b4",
  measurementId: "G-GLBPC1FS8Q"
};

const app2 = initializeApp(firebaseConfig);

const app = createApp(App)
const db = getDatabase();

export {
  db
}

app.use(createPinia())
app.use(router)

app.mount('#app')
